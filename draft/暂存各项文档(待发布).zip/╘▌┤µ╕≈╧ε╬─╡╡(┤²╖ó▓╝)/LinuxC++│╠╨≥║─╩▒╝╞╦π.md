```c++
    //头文件
    //1
    #include <time.h>
    //2
    #include <chrono>
	using std::chrono::high_resolution_clock;
	using std::chrono::milliseconds;
    //3
    #include <chrono>
    using namespace std::chrono;
    
    
    
    //开始计时
    //1
    const clock_t begin_time = clock(); 
    //2
    high_resolution_clock::time_point beginTime = high_resolution_clock::now();
    //3
    auto starttime = system_clock::now();
    
    //do something
    
    //结束计时并计算时间
    //1
    float seconds = float(clock() - begin_time) / 1000;    //最小精度到ms
    printf("used time 1(seconds) = %f\n",seconds);
    //2
    high_resolution_clock::time_point endTime = high_resolution_clock::now();
    milliseconds timeInterval = std::chrono::duration_cast<milliseconds>(endTime - beginTime);
    printf("used time 2(milliseconds) = %d\n",timeInterval.count());
    //3
    duration<double> diff = system_clock::now()- starttime;
    printf("used time 3(seconds) = %f\n",diff.count());
```

## 1 clock()

C 库函数 **clock_t clock(void)** 返回程序执行起（一般为程序的开头），处理器时钟所使用的时间。

https://www.runoob.com/cprogramming/c-function-clock.html

## 2 high_resolution_clock::now()

Returns a time point representing the current point in time.

https://en.cppreference.com/w/cpp/chrono/high_resolution_clock/now

https://www.cnblogs.com/zhongpan/p/7490657.html

std::chrono是C++11引入的日期时间处理库，其中包含3种时钟：system_clock，steady_clock，high_resolution_clock

## 3 system_clock::now()

所谓时钟，是指从一个时点开始，按照某个刻度的一个计数。

system_clock，其起点是epoch，即1970-01-01 00:00:00 UTC，其刻度是1个tick，也就是_XTIME_NSECS_PER_TICK纳秒。