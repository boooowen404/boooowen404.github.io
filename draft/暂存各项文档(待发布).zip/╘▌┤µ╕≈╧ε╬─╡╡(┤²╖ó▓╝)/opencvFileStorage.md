功能：

将某些支持的类保存为XML/YAML/JSON文件

官方文档：

https://docs.opencv.org/4.x/da/d56/classcv_1_1FileStorage.html#a973e41cb75ef6230412a567723b7482da049591e6d1749b29bb206909c70b2470

示例代码：

```c++

#include <string>
#include <iostream>
#include <fstream>
#include <vector>


#include <Eigen/Core>
#include <opencv2/core/core.hpp>

using namespace std;

struct ImuData
{
    Eigen::Vector3f AngularVel;
    Eigen::Vector3f LinearAccel;
    double TimeInterval;
    double Timestamp;

    ImuData()
    {
        AngularVel.setZero();
        LinearAccel.setZero();
        TimeInterval = 0.;
        Timestamp = 0.;
    }

    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
};

struct ImageData
{
    cv::Mat Image;
    double Timestamp;

    ImageData()
    {
        Image = cv::Mat();
        Timestamp = 0.;
    }

    ~ImageData()
    {
        Image.release();
    }
};



int main()
{
	ImuData imudata1;
	ImageData imagedata1,imagedata2,imagedata3;
	imagedata1.Timestamp = 1;
	imagedata2.Timestamp = 2;
	imagedata3.Timestamp = 3;

	//save image Mat
	cv::FileStorage fs_write("image_data.xml",cv::FileStorage::WRITE);
	fs_write<<"image_data3_timestamp"<<imagedata3.Timestamp;
	fs_write<<"image_data2_timestamp"<<imagedata2.Timestamp;
	fs_write<<"image_data3_mat"<<imagedata3.Image;
	fs_write<<"image_data2_mat"<<imagedata2.Image;
	fs_write.release();

	//load image Mat
	cv::FileStorage fs_read("image_data.xml", cv::FileStorage::READ);
	ImageData imagedata_read2,imagedata_read3;
	fs_read["image_data2_timestamp"] >> imagedata_read2.Timestamp;
	fs_read["image_data3_timestamp"] >> imagedata_read3.Timestamp;
	fs_read["image_data2_mat"] >> imagedata_read2.Image;
	fs_read["image_data3_mat"] >> imagedata_read3.Image;
	cout<<"data 2 timestaem = "<<imagedata_read2.Timestamp<<endl;
	cout<<"data 3 timestaem = "<<imagedata_read3.Timestamp<<endl;

	return 0;
}

```

