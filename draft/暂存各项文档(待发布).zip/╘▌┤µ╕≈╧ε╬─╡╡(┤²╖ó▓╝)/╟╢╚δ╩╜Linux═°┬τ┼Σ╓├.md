可以使用**NetworkManager服务**

简介：

NetworkManager由一个管理系统网络连接、并且将其状态通过D-BUS（是一个提供简单的应用程序互相通讯的途径的自由软件项目，它是做为freedesktoporg项目的一部分来开发的）进行报告的后台服务，以及一个允许用户管理网络连接的客户端程序。

说人话的简介：

一个管理网络的服务

命令：

配置IP(重启仍然生效)：

```
nmcli con add con-name "static-eth0" ifname eth0 type ethernet ip4 10.28.9.115/22 gw4 10.28.9.1
nmcli con up "static-eth0" iface eth0
```

第一句是新增一个”connection/con“绑定到eth0上，并且配置IP，子网掩码和网关？网关有什么用？

这里子网掩码是用？格式表示的，22代表255.255.252.0，24代表255.255.255.0

"static-eth0"是网络名称



看这篇文章：

https://blog.csdn.net/weixin_40543283/article/details/83374388