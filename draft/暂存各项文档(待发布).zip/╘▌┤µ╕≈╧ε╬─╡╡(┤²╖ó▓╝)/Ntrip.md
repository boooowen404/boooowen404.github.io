### 是什么？

NTRIP（ Networked Transport of RTCM via Internet Protocol）是一种通讯协议

### 有什么用？

随着 GPRS、CDMA、3G 技术的发展，高传输率、高宽带、覆盖范围广的无线传输通讯方式成为 GPS 实时差分数据的的一种方式。国际上，通常采用 Ntrip（NetWorked  Transport  of  RTCM  via  Internet  Protocol）协议来实现 CORS（Continues  Operation  Reference  System）观测站和用户之间差分数据的无线传输。
### 原理是什么？

它的基础是 HTTP网络通用协议，建立在网络 TCP / IP 协议基础之上。Ntrip 协议由德国制图与测地学联邦代理处( the Federal Agency for Cartography and Geodesy of Germany，简称 BKG)发起，得到了 RTCM 委员会认证。Ntrip 网络管理模式使得 CORS 系统建设变得简单，保证了 CORS 系统运行的安全、可靠和用户的权益。
### Ntrip网络的组成是什么？

Ntrip 网络主要由 3 个部分组成：Ntrip 客户端（Ntrip Client）、Ntrip 服务器（Ntrip Server）和 Ntrip 处理中心（NtripCaster）。这里的 Ntrip 客户端和 Ntrip 服务器都只相当于 HTTP 连接中的客户端，Ntrip 处理中心才是响应它们的服务处理器。

![在这里插入图片描述](./Ntrip/1.png)

在 CORS 网络中，Ntrip Client 是指接收 RTK 数据流的用户站设备，Ntrip Client 使用 Ntrip Caster 分配的 IP 地址通过互联网连接到 NtripCaster。Ntrip Server 这部分用于从 GPS 参考站网络得到 Ntrip Caster 传输的 RTK 数据。在CORS 系统中 Ntrip  服务器（硬件）通常是运行 CORS 系统管理软件的计算机。Ntrip 服务器给产生不同差分数据格式的数据源（Ntrip Source）分配一个节点名（mountpoint），Ntrip  处理中心就将多个节点名列表制成源列表(Source Table)  。Ntrip Client 访问请求 NtripCaster 分配的 IP 地址时就可以收到这张源列表，根据源列表的信息，客户可以自由选择自己需要的数据格式。

#### 总结如下：

- NtripSource：用来产生GPS差分数据，并把差分数据提交给NtripServer
- NtripServer：负责把GPS差分数据提交给NtripCaster
- NtripCaster：差分数据中心，负责接收、发送GPS差分数据
- NtripClient：登录NtripCaster后，NtripCaster把GPS差分数据发送给它

![在这里插入图片描述](./Ntrip/2.png)

NtripSource 和 NtripServer 一般已经集成到一台GPS基准站内，GPS基准站产生差分数据（扮演着NtripSource的角色），然后再通过网络发送给NtripCaster（扮演着NtripServer的角色）。

（Ntripsource定义唯一的sourceID，并称为挂载点（mountpoint））

NtripSource 和 NtripServer也可以分开：GPS基准站产生差分数据，然后通过串口发送给一个程序，这个程序再把差分数据发送给NtripCaster。这里GPS基准站扮演着NtripSource的角色，程序扮演着NtripServer的角色。

NtripCaster一般就是一台固定IP地址的服务器，它负责接收、发送差分数据。

**给NtripClient发送差分数据时有两种方案**：一是直接转发NtripSource产生的差分数据；二是通过解算多个NtripSource的差分数据，为NtripClient产生一个虚拟的基准站（即VRS）。

NtripClient一般就是GPS流动站。登录NtripCaster后，发送自身的坐标给NtripCaster。NtripCaster选择或产生差分数据，然后发送给NtripClient。这样GPS流动站即可实现高精度的差分定位。

### 有什么优点：

Ntrip 网络具有如下优势：
(1)   Ntrip  协议是一种公开的标准协议，   NtripClient 、 Ntrip Server 和Ntrip Caster 应用程序都可以在网络上下载，数据处理中心、用户端只要支持 Ntrip控件，就能按照 Ntrip 协议规定进行差分数据传输；
(2)    Ntrip  协议可以传输不同格式的数据，  除 RTCM 数据外，  CMR、FKP、MAX 等各种数据只要遵循 Ntrip 的管理规定都可以进行传输；
(3)    Ntrip 网络将 CORS 系统的各个组成部分分成独立而又能有效连接的部分。CORS 系统的参考站可以选用不同的接收机，系统数据处理软件也可以不尽相同，不同处理软件都可以充当 Ntrip Server 的角色，处理得到的差分源数据按照 Ntrip  协议规定作为 Ntrip Caster 中不同的节点，客户访问网络时就可以根据 Ntrip Caster 的路径指引很快地和需要的数据节点建立连接。这种作业模式，使得不同区域、不同 CORS 技术网络的资源都可以在 internet 网络中共享，用户直接面对的是 Ntrip Caster，而不需要关心 CORS 系统的内部运作；

(4)    CORS 网络通过 Ntrip  进行工作，  用户访问 CORS 网络就和访问一个Internet 网络页面那么简单。用户根据数据中心给的 IP 地址和端口，就很容易收到 Ntripcaster 制定的源列表信息，从源列表中就可以选定自己需要的格式的数据，直接和提供该数据的节点建立联系；
(5)   Ntrip 网络允许多用户同时访问；
(6)   Ntrip 网络管理时需要用户使用合法的用户名和密码，NtripClient 只有以合法身份才能连接到 Ntrip Caster。这样能提供网络安全性，并预防非注册用户进入到数据处理中心收发数据，保护数据服务器的数据。而且通过用户管理，数据处理中心就可以很方便地知道哪个流动站已经登陆和在线时长，可以依此信息进行收费。

### NtripClient访问NtripCaster步骤

NtripClient访问NtripCaster一般有两个目的

- 获取源列表
- 获取差分数据

#### 获取源列表

源列表指的是差分数据数量、格式等，我的理解为获取差分数据列表，以便从中选择自己需要的

步骤如下：

1. 与NtripCaster建立TCP连接

2. 给NtripCaster发送请求

3. NtripCaster返回状态数据和当前时刻等数据，然后断开TCP连接

#### 获取差分数据

NtripCaster给NtripClient发送差分数据时分两种情况：

1. 直接转发NtripSource产生的差分数据。在这种情况下，NtripClient只要指定挂载点即可；
2. 通过解算多个NtripSource的差分数据，为NtripClient产生一个虚拟的基准站。在这种情况下，NtripClient不仅要指定挂载点，还要发送自身的坐标给NtripCaster，NtripCaster根据这个坐标才能产生虚拟基准站。

不同情况下NtripClient需要给NtripCaster发送的数据不同，需要的数据在NtripCaster获取源列表步骤中发送的数据内。

获取差分数据的过程如下：

1. 与NtripCaster建立TCP连接

2. 给NtripCaster发送请求，包括用户名、密码等

3. NtripCaster返回状态数据和当前时刻等数据，然后断开TCP连接

4. 给NtripCaster发送GGA数据(从接收机NMEA中获取)，有的挂载点不需要发送该数据

5. NtripCaster收到GGA数据后，将给NtripClient发送差分数据。

比较好的文章：

https://blog.csdn.net/mayue_web/article/details/121020565

